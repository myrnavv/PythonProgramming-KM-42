from factorial.factorial import fact
from exp_root.exponentiation import exp2, exp3
from exp_root.root import root2, root3
from logarithm.logarithm import log, ln, lg

def main():
    while True:
        print('\nChoose an operation:')
        print('1. Factorial')
        print('2. Exponentiation')
        print('3. Roots')
        print('4. Logarithms')
        print('5. Exit')
        
        try:
            choice = int(input('Enter your choice (1-5): '))
        except ValueError:
            print('Invalid input. Enter a number between 1 and 5.')
            continue
        
        if choice == 1:
            # Factorial
            while True:
                try:
                    num = int(input('Enter a natural number for factorial calculation: '))
                    if num < 0:
                        print('Factorial is not defined for negative numbers.')
                        continue
                    print(f'\nFactorial of {num} is {fact(num)}')
                    break
                except ValueError:
                    print('Invalid input. Enter a natural number.')
        
        elif choice == 2:
            # Exponentiation
            while True:
                try:
                    num = float(input('Enter a number to exponentiate: '))
                    exp_choice = input('Enter "2" for square or "3" for cube: ')

                    if exp_choice == '2':
                        print(f'\nThe square of {num} is {exp2(num)}')

                    elif exp_choice == '3':
                        print(f'\nThe cube of {num} is {exp3(num)}')

                    else:
                        print('Invalid choice for exponentiation.')
                        continue
                    break
                except ValueError:
                    print('Invalid input. Enter a valid number.')
        
        elif choice == 3:
            # Roots
            while True:
                try:                    
                    root_choice = input('Enter "2" for square root or "3" for cube root: ')

                    if root_choice == '2':
                        num = float(input('Enter a positive number to find its root: '))
                        if num < 0:
                            print('Square roots are not defined for negative numbers.')
                            continue
                        print(f'\nThe square root of {num} is {root2(num)}')

                    elif root_choice == '3':
                        num = float(input('Enter a number to find its root: '))
                        if num < 0:
                            num = float(str(num)[1:])
                            print(f'\nThe cube root of -{num} is -{root3(num)}')
                        else:
                            print(f'\nThe cube root of {num} is {root3(num)}')

                    else:
                        print('Invalid choice for roots.')
                        continue
                    break
                except ValueError:
                    print('Invalid input. Enter a valid number.')
        
        elif choice == 4:
            # Logarithms
            while True:
                try:
                    log_choice = input('Enter "log" for logarithm, "ln" for natural log, or "lg" for base-10 log: ').lower()

                    if log_choice == 'log':
                        a = float(input('Enter the base (a > 0 and a != 1): '))
                        b = float(input('Enter the number (b > 0): '))
                        if a <= 0 or a == 1 or b <= 0:
                            print('Invalid base or number for logarithm.')
                            continue
                        print(f'\nlog_{a}({b}) = {log(a, b)}')

                    elif log_choice == 'ln':
                        b = float(input('Enter the number (b > 0): '))
                        if b <= 0:
                            print('Invalid number for natural logarithm.')
                            continue
                        print(f'\nln({b}) = {ln(b)}')

                    elif log_choice == 'lg':
                        b = float(input('Enter the number (b > 0): '))
                        if b <= 0:
                            print('Invalid number for base-10 logarithm.')
                            continue
                        print(f'\nlg({b}) = {lg(b)}')

                    else:
                        print('Invalid choice for logarithm.')
                        continue
                    break
                except ValueError:
                    print('Invalid input. Enter valid numbers.')
        
        elif choice == 5:
            break
        
        else:
            print('Invalid input. Please enter a number between 1 and 5.')

if __name__ == '__main__':
    main()
