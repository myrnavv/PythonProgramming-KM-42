import math

def root2(x):
    '''
    Returns the square root of x
    '''
    return round(math.sqrt(x), 3)

def root3(x):
    '''
    Returns the cube root of x
    '''
    return round(x ** (1/3), 3)
