def exp2(x):
    '''
    Returns x raised to the power of 2
    '''
    return round(x ** 2, 3)

def exp3(x):
    '''
    Returns x raised to the power of 3 
    '''
    return round(x ** 3, 3)
