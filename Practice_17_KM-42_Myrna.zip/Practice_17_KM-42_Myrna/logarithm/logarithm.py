import math

def log(a, b):
    '''
    Returns the logarithm of b with base a
    '''
    return round(math.log(b, a), 3)

def ln(b):
    '''
    Returns the natural logarithm of b
    '''
    return round(math.log(b), 3)

def lg(b):
    '''
    Returns the base-10 logarithm of b
    '''
    return round(math.log10(b), 3)
